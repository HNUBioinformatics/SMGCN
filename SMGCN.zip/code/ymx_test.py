"""
# -*- coding: utf-8 -*-
# @Author : Sun JJ
# @File : ymx_test.py
# @Time : 2022/4/19 20:29
# code is far away from bugs with the god animal protecting
#         ┌─┐       ┌─┐
#      ┌──┘ ┴───────┘ ┴──┐
#      │                 │
#      │       ───       │
#      │  ─┬┘       └┬─  │
#      │                 │
#      │       ─┴─       │
#      │                 │
#      └───┐         ┌───┘
#          │         │
#          │         │
#          │         │
#          │         └──────────────┐
#          │                        │
#          │                        ├─┐
#          │                        ┌─┘
#          │                        │
#          └─┐  ┐  ┌───────┬──┐  ┌──┘
#            │ ─┤ ─┤       │ ─┤ ─┤
#            └──┴──┘       └──┴──┘
"""

import numpy as np



data_path = '../data/ymx/'
data_set = 'data/'
adj_triple = np.loadtxt(data_path + data_set + 'new_mat_drug_protein.txt')


print(adj_triple,adj_triple.shape)
print(adj_triple[:, 2])
print(adj_triple[:, 0] - 1)
print(adj_triple[:, 1] - 1)

for i in adj_triple[:, 1] - 1:
    print(i,type(i))

# with open(data_path + data_set + 'adj.txt','r') as f:
#     data = f.readlines()
#
# for i in data:
#     print(i)


# import numpy as np
#
# our_adj = np.loadtxt('../data/ymx/data/mat_drug_protein.txt')
#
# for i in range(our_adj.shape[0]):
#     for j in range(our_adj.shape[1]):
#         if our_adj[i][j] == 1:
#             with open('../data/ymx/data/new_mat_drug_protein.txt','a') as f:
#                 f.write(str(i) + '\t' + str(j) + '\t' + str(1) + '\n')