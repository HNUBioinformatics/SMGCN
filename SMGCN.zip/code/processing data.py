import os
os.chdir('../data/ymx/data/蛋白序列相似矩阵')
import numpy as np

with open('./e_simmat_dg.txt', 'r') as f:
    wbu = f.readlines()

wbu = wbu[1:]
wbu = [i[:-1] for i in wbu]


list_all = []
count = 0

for line in wbu:
    arr_line = np.array(line.split('\t')[1:], dtype=float)
    list_all.append(arr_line)
    count += 1
    # print(count)

e_sim_dg = np.array(list_all)
print(e_sim_dg)
print(e_sim_dg.shape)
np.save("e_simmat_dg.npy",e_sim_dg)


# sun=np.load("./e_simmat_dg.npy")
# print(sun.shape)