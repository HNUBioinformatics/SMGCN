# import torch as t
# import numpy as np
# import pandas as pd
# from torch.autograd import Variable
#
#
#
# # k=Variable(t.FloatTensor(1)).cuda
# # m=Variable(t.FloatTensor(1)).cuda
#
# K = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
# M = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
#
# data_path = '../Data/ymx/'
# data_set = 'data/'
# a= np.loadtxt(data_path + data_set + 'Similarity_Matrix_Drugs.txt')
# b = np.loadtxt(data_path + data_set + 'drug_ra_sim.txt')
# c = np.loadtxt(data_path + data_set + 'Similarity_Matrix_Proteins.txt')
# # d= np.loadtxt(data_path + data_set + 'target_ra_sim.txt')
# # d = np.genfromtxt(data_path + data_set + 'target_ra_sim.csv',dtype = float)
# d = pd.read_csv(data_path + data_set + 'target_ra_sim.csv',header = None)    # 将csv文件读取为dataframe形式
# d = d.values     # dataframe转换为numpy数组
#
# for k in K:
#     drug_sim=k*a+(1-k)*b
#     print(drug_sim)
#     print(type(drug_sim))
#
# # for m in M:
# #     mic_sim=m*c+(1-m)*d


import torch
from torch.autograd import Variable

x = Variable(torch.ones(2, 2), requires_grad=True)
print(x)
print("---------")
print(x.data)

k=Variable(torch.FloatTensor(1))
m=Variable(torch.FloatTensor(1))
print(k.data,m)