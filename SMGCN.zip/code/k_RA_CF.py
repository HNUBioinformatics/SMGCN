import numpy
import numpy as np
import pandas as pd
import scipy
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import KFold
import random
import os
os.chdir('../data/ymx/data/药物-靶标相互作用数据的邻接矩阵')


# test_file_path='raw_data/Dataset3/mat_drug_protein.csv'
test_file_path = '../data/ymx/data/药物-靶标相互作用数据的邻接矩阵/gpcr_admat_dgc.npy'

def ra_similarity(x):
    ss=sum(x)
    ss[ss==0]=1
    result_1 = x /ss  # !!!!!sum默认是按照列求和
    y = np.array(result_1)  # 第一次传播--质量分配
    # print("第一次传播：\n",y)

    '''第2.1传播：均分'''
    result_2 = []
    y = np.squeeze(y)  # 去掉第一个维度   不知道为啥在k_yangzheng 调用后维度2变成3了
    for i in range(y.shape[0]):
        if x[i, :].sum() == 0:  # 训练测试集万一该列为空，避免相除报错
            continue
        result_2.append(y[i, :] / np.count_nonzero(y[i, :]))
    z = np.array(result_2)
    # print("第2.1次：\n", z)

    '''第2.2'''
    z_result = np.zeros((z.shape[1], z.shape[1]))
    for i in range(z.shape[1]):  # !!!!
        ii = np.where(z[:, i] > 0)
        # list(ii)[0]=每列不为0的索引  sum(axis=0)=数组按行相加
        z_result[i] = z[list(ii)[0], :].sum(axis=0)
    return z_result

if __name__ == '__main__':

    train_set = np.load(test_file_path)
    train_set = numpy.array(train_set)
    train_set = train_set.T
    a=ra_similarity(train_set)
    print(a.shape)
    # np.save("nr_admat_dgc_rasim_d.npy",a)
    np.save("gpcr_admat_dgc_rasim_p.npy", a)
    print(ra_similarity(train_set))









